<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>

<style>
	
	button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}

</style>
</head>
<body>

<button id="dashboard">Dashboard </button>
<button id="members">Members </button>
<button id="issue_books">Issue Books </button>
<button id="issued_books">Issued Books </button>
<button id="institution">Institution </button>
<button id="application">Applications </button>
<button id="my_profile">My Profile </button>
<button id="logout">Log Out </button>


<script type="text/javascript">
	
	document.getElementById("dashboard").onclick= function()
	{

		location.href="dashboard.php";
	};

	document.getElementById("members").onclick= function()
	{

		location.href="members.php";
	};

	document.getElementById("issue_books").onclick= function()
	{

		location.href="issue_books.php";
	};

	document.getElementById("issued_books").onclick= function()
	{

		location.href="issued_books.php";
	};

	document.getElementById("institution").onclick= function()
	{

		location.href="institution.php";
	};

	document.getElementById("application").onclick= function()
	{

		location.href="application.php";
	};

	document.getElementById("my_profile").onclick= function()
	{

		location.href="my_profile.php";
	};

	document.getElementById("logout").onclick= function()
	{

		location.href="logout.php";
	};

	
</script>
</body>
</html>