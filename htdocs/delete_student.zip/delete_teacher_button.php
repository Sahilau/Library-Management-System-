<?php

$id= $_GET['id'];

		include "connection.php";			
	
		$sql2="DELETE FROM teachers WHERE id='$id'";

		$result2=mysqli_query($con, $sql2);
		{
			if ($result2)
			{
				echo "<script> alert('Record Deleted Successfully');
								window.location.href='delete_teacher.php'; </script>";
				//header("Location: delete_teacher.php");
			}
			else
			{
				echo "Unable To Delete Record:".mysqli_error($con);
			}
		}
						

?>