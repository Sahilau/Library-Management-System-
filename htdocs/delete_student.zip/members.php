<!DOCTYPE html>
<html>
<head>
	<title>Members</title>

	<style>
	
	button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}

</style>
</head>
<body>

	<button id="students">Students </button>
	<button id="teachers">Teachers </button>

<script type="text/javascript">
	
	document.getElementById("students").onclick= function()
	{

		location.href="students.php";
	};
	
	document.getElementById("teachers").onclick= function()
	{

		location.href="teachers.php";
	};
</script>
</body>
</html>