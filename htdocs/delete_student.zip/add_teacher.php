<?php
	if (isset($_POST['submit']))
	{
		
		include "connection.php";

		$tname= $_POST['tname'];
		$branch= $_POST['branch'];
		$designation= $_POST['designation'];
		$phone= $_POST['phone'];




		$sql="INSERT INTO teachers(tname, branch, designation, phone)
				values('$tname','$branch','$designation', '$phone')";

				$result=mysqli_query($con, $sql);
				if($result==true)
				{
					echo "<script> alert('Added Successfully'); </script>";

				}
				else
				{
					echo "ERROR :".mysqli_error($con);
				}
	}

?>




<!DOCTYPE html>
<html>
<head>
	<title>Add Teacher</title>
</head>
<body>
	<form method="POST">
		<label for="tname">Name :</label> 
		<input type="text" name="tname" id="tname" required><br><br>

		<label for="branch">Branch :</label> 
		<select id="branch" name="branch" required>
			
			<option >Computer</option>
			<option >IT</option>
			<option >Mechanical</option>
			<option >Electrical</option>
			<option >Civil</option>
		</select><br><br>

		<label for="designation">Designation :</label> 
		<select id="designation" name="designation" required>
			
			<option >HOD</option>
			<option >Senior Lecturer</option>
			<option >Lecturer</option>
		</select><br><br>


		<label for="phone">Phone :</label> 
		<input type="text" name="phone" id="phone" required><br><br><br>

		<input type="submit" name="submit" value="Add Teacher">
	</form>

</body>
</html>