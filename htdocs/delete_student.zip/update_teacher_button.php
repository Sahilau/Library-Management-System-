<?php

$id= $_GET['id'];
$tname= $_GET['tname'];
$branch= $_GET['branch'];
$designation= $_GET['designation'];
$phone= $_GET['phone'];
?>



<!DOCTYPE html>
<html>
<head>
	<title>Add Teacher</title>
</head>
<body>
	<form method="POST">
		<label for="tname">Name :</label> 
		<input type="text" name="tname" id="tname" value="<?php echo $tname; ?>" required><br><br>

		<label for="branch">Branch :</label> 
		<select id="branch" name="branch" value="<?php echo $branch; ?>" required>
			
			<option >Computer</option>
			<option >IT</option>
			<option >Mechanical</option>
			<option >Electrical</option>
			<option >Civil</option>
		</select><br><br>

		<label for="designation">Designation :</label> 
		<select id="designation" name="designation" value="<?php echo $designation; ?>" required>
			
			<option >HOD</option>
			<option >Senior Lecturer</option>
			<option >Lecturer</option>
		</select><br><br>


		<label for="phone">Phone :</label> 
		<input type="text" name="phone" id="phone" value="<?php echo $phone; ?>"required><br><br><br>

		<input type="submit" name="submit" value="Update Details">
	</form>

</body>
</html>

<?php

if (isset ($_POST['submit']))
{
	$updated_tname= $_POST['tname'];
	$updated_branch= $_POST['branch'];
	$updated_designation= $_POST['designation'];
	$updated_phone= $_POST['phone'];



	include "connection.php";

	$sql="UPDATE teachers SET tname='$updated_tname', branch='$updated_branch', designation='$updated_designation', phone='$updated_phone' WHERE id='$id'";

	$result=mysqli_query($con, $sql);

	if ($result)
	{
		echo "<script> alert('Record Updated Successfully');
								window.location.href='update_teacher.php'; </script>";
		//header ("Location: update_teacher.php");
	}

	else
	{
		echo "Unable To Update Records :".mysqli_error($con);
	}
}



?>
