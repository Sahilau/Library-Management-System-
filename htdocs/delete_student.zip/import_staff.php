<!DOCTYPE html>
<html>
<head>
	<title>Import Staff</title>
	<style>
	
	button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}

</style>
</head>
<body>
	<button>All Staff</button><br><br>
	<h2>Click Here To Add Institution Staff To Library :</h2><br><br>
	<button>Import New Staff</button>

</body>
</html>