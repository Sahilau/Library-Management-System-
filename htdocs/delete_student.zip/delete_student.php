<?php

	include "connection.php";


	$sql = "SELECT * from students";
	$result = mysqli_query($con, $sql);

	if (mysqli_num_rows($result) > 0) 

	{
		?>

		<!DOCTYPE html>
	  	  <html>
	  	  <body>
	  	  	<table border="2">
	  	  		
	  	  		<tr>
	  	  			<th> Student ID </th>
	  	  			<th> Student Name </th>
	  	  			<th> Father Name </th>
	  	  			<th> Phone no. </th>

	  	  		</tr>

	  	  		
	  	  				<?php
	  	// output data of each row
	  	while($row = mysqli_fetch_assoc($result)) 

	  	{
	  	  	echo "<tr><td>".$row['id']."</td><td>".$row['sname']."</td><td>".$row['fname']."</td><td>".$row['phone'];
	  	
			?>

	  	     
	  	  
	  	  <?php

	  	 

	  	}

	} 
	
	else 
		{
			 echo "0 results";
		}

		mysqli_close($con);




?>
</td>	
	  	  		</tr>
	  	  	</table>

	  	  
	  	  </body>
	  	  </html>

<!DOCTYPE html>
<html>
<head>
	<title>All Students</title>
</head>
<body>



</body>
</html>