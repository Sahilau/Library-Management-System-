

<!DOCTYPE html>
<html>
<head>
	<title>Student</title>

	<style>
	
	button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}

</style>
</head>
<body>

		<button id="all_students">All Students </button>
		<button id="delete_student">Delete Student </button>
		<button id="update_student">Update Student Details </button>
<script type="text/javascript">
	
	document.getElementById("all_students").onclick= function()
	{

		location.href="view_students.php";
	};

	
	document.getElementById("delete_student").onclick= function()
	{

		location.href="delete_student.php";
	};

	
	document.getElementById("update_student").onclick= function()
	{

		location.href="update_student.php";
	};

</script>
</body>
</html>