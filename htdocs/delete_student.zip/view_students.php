<?php

	include "connection.php";


	
		$sql = "SELECT * FROM lib_students";
		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) > 0) 
		{
			echo "<table border='2'>";
		 	echo "<tr>";
		 	echo "<td>"."ID"."</td>";
		 	echo "<td>"."Student Name"."</td>";
		 	echo "<td>"."Father Name"."</td>";
		 	echo "<td>"."Phone No."."</td>";
		 	echo "<td>"."Date of Birth"."</td>";

		 	echo "</tr>";

		    
		  // output data of each row
		  while($row = mysqli_fetch_assoc($result))
		 
		 {
		 	
			echo "<tr>";
			echo "<td>".$row['id']."</td>";
			echo "<td>".$row['sname']."</td>";
			echo "<td>".$row['fname']."</td>";
			echo "<td>".$row['phone']."</td>";
			echo "<td>".$row['dob']."</td>";
			echo "</tr>";	
			echo "</table>";		    
		    
		  }
		} 
		else 
		{
		  echo "Empty";
		}

		mysqli_close($con);
	

?>


<!DOCTYPE html>
<html>
<head>
	<title>All Students</title>
</head>
<body>



</body>
</html>