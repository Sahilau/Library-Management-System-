<?php

	include "connection.php";


	
		$sql = "SELECT * FROM teachers";
		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) > 0) 
		{
			echo "<table border='2' cellspacing='5'>";
		 	echo "<tr>";
		 	echo "<td>"."Name"."</td>";
		 	echo "<td>"."Branch"."</td>";
		 	echo "<td>"."Designation"."</td>";
		 	echo "<td>"."Phone no."."</td>";
		 	echo "<td>"."Operation"."</td>";
		 	echo "</tr>";

			    
			  // output data of each row
			  while($row = mysqli_fetch_assoc($result))
			 
			  {
			 	
					echo "<tr>";
					echo "<td>".$row['tname']."</td>";
					echo "<td>".$row['branch']."</td>";
					echo "<td>".$row['designation']."</td>";
					echo "<td>".$row['phone']."</td>";
				    echo "<td>"."<a href='update_teacher_button.php?id=$row[id]& tname=$row[tname]& branch=$row[branch]& designation=$row[designation]& phone=$row[phone]'>".'Update'."</a>"."</td>";
					echo "</tr>";
				 

			  }		echo "</table>";

		} 
		else 
		{
		  echo "Empty";
		}

		


		
			mysqli_close($con);
			

		
			

?>


<!DOCTYPE html>
<html>
<head>
	<title>All Students</title>
</head>
<body>



</body>
</html>