




    <!DOCTYPE html>    
    <html>    
    <head>    
        <title>Home</title>    
        <link rel="stylesheet" type="text/css" href="css/style.css">    
  

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <style>      
    body  
    {  
        background-image: url('img9.jpg');
        -webkit-background-size: cover;
        -moz-background-size: cover;
        background-size: cover;
        margin: 0px;  
        padding: 0px;  
        position: absolute;
        width: 100%;
        font-family: 'Arial';  
    }  
      
   .btn
   {
    
        width: 30%;
        height: 30%;
        padding: 100px;

   }


    h2{  
        font-family: Arial, Helvetica, sans-serif;
        font-weight: bolder;
        text-align: center;  
        color: #277582;  
        padding: 20px;  
    }  
     
    
   
    
    
  </style>
</head>


    <body>  

 
        <h2>Welcome to Library </h2>  </br></br>
        <div class="container">
<a href="admin_login.php" class="btn btn-info btn-lg"> </br> Admin
<span class="glythicun glythicun-user"></span></a>
<a href="signup.php" class="btn btn-info btn-lg"> </br> Student

</a></div>

</body>
</html>

