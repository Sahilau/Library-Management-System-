<?php
		include "connection.php";

		$sql="select * from allBooks";
		if ($result=mysqli_query($con, $sql)) 
		{
			$rowcount=mysqli_num_rows($result);
		}

		mysqli_close($con);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
</head>
<body>

<form>
	<label for="total_books">Total Number Of Books:</label>
	<input type="text" name="total_books" id="total_books" value="<?php echo $rowcount; ?>" disabled><br><br>

	<label for="registered_students">Number Of Students Registered:</label>
	<input type="text" name="registered_students" id="registered_students" disabled><br><br>

	<label for="registered_teachers">Number Of Teachers Registered:</label>
	<input type="text" name="registered_teachers" id="registered_teachers" disabled><br><br>

	<label for="issued_books">Number Of Issued Books:</label>
	<input type="text" name="issued_books" id="issued_books" disabled><br><br>

	<label for="applications">Applications:</label>
	<input type="text" name="applications" id="applications" disabled><br><br>
</form>
</body>
</html>