<!DOCTYPE html>
<html>
<head>
	<title>Teacher</title>

	<style>
	
	button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}

</style>
</head>
<body>

		<button id="all_teachers">All Teachers </button>
		<button id="add_teacher">Add Teacher </button>
		<button id="delete_teacher">Delete Teacher </button>
		<button id="update_teacher">Update Teacher Details </button>


<script type="text/javascript">
	
	document.getElementById("all_teachers").onclick= function()
	{

		location.href="view_teacher.php";
	};

	document.getElementById("add_teacher").onclick= function()
	{

		location.href="add_teacher.php";
	};


	


	
	document.getElementById("delete_teacher").onclick= function()
	{

		location.href="delete_teacher.php";
	};




	
	document.getElementById("update_teacher").onclick= function()
	{

		location.href="update_teacher.php";
	};

</script>
</body>
</html>