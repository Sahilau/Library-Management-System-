<?php
	include 'connection.php';

  //displaying student table






  $sql = "SELECT * from students";
  $result = mysqli_query($con, $sql);

  if (mysqli_num_rows($result) > 0) 

  {
    ?>

    <!DOCTYPE html>
        <html>
        <body>
          <table border="2">
            
            <tr>
              <th> Student ID </th>
              <th> Student Name </th>
              <th> Father Name </th>
              <th> Phone no. </th>

            </tr>

            
                <?php
      // output data of each row
      while($row = mysqli_fetch_assoc($result)) 

      {
          echo "<tr><td>".$row['id']."</td><td>".$row['sname']."</td><td>".$row['fname']."</td><td>".$row['phone'];
      
      ?>

           
        
        <?php

       

      }

  } 
  
  else 
    {
       echo "0 results";
    }

    mysqli_close($con);




?>
</td> 
            </tr>
          </table>

        
        </body>
        </html>

<!DOCTYPE html>
<html>
<head>
  <title>All Students</title>
</head>
<body>



</body>
</html>


<?php
//$uploadfile=$_FILES['uploadfile']['tmp_name'];

require 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';

$objExcel=PHPExcel_IOFactory::load("C:\Users\Sahil\Desktop\Book1.xlsx");
foreach($objExcel->getWorksheetIterator() as $worksheet)
{
  $highestrow=$worksheet->getHighestRow();

  for($row=0;$row<=$highestrow;$row++)
  {
    $sname=$worksheet->getCellByColumnAndRow(0,$row)->getValue();
    $fname=$worksheet->getCellByColumnAndRow(1,$row)->getValue();

    $branch=$worksheet->getCellByColumnAndRow(2,$row)->getValue();
    $phone=$worksheet->getCellByColumnAndRow(3,$row)->getValue();
    
      $sql="INSERT INTO `i_students`( sname, fname, branch, phone) VALUES ('$sname','$fname', '$branch', '$phone')";
     
  }
}

?>


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>


.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;

  
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

button
	{
      	margin-right: 35px;
      	margin-top: 10px;
      	font-size: 20px;
      	padding: 10px;
	}


</style>
</head>
<body>

<button class="open-button" onclick="allStudents()">All Students</button><br><br>


<h3>Click Here To Import New Students</h3>
<button class="open-button" onclick="importForm()">Import New Students</button>

<br><br>
<div class="form-popup" id="myForm">
  <form action="import_students.php" class="form-container">
    

    <form>
  <div class="form-group">
    <label for="uploadfile">Upload Excel File To Import</label><br><br>
    <input type="file" class="form-control-file" id="uploadfile"><br><br>
  
    <button type="submit" class="btn" onclick="importButton()">Import</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Cancel</button>
  </form>
</div>

<script>
function importForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

</body>
</html>
