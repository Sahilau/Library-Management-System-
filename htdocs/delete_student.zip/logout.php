<?php
	
	session_start();
	echo $_session['username'];
	session_destroy();

	//header("Location: start_project.php");

?>

